module('requireJS');

asyncTest('test requireJS support', function() {
    expect(1);
    require(['jquery', '../dist/jquery.countdown'], function( $ ) {
        start();
        ok( !!$.fn.countdown, "Should load the plugin via requireJS" );
    });
});